<?php
 $a="10 32 45 56";
 $b=explode(" ",$a);
 for($c=0;$c<count($b);$c++)
	 echo $b[$c];
?>