<html>
<body>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 body{
	  
	  background-image:url("thumb-1920-848573.jpg");
	   background-size:100% 120%;
	    background-repeat:no-repeat;
		font-family: Arial, Helvetica, sans-serif
  
  }
   .navbar
 {
    background-color:transparent;
	text-color: blue;
    position:fixed; 
	top: 0;
	width: 110%;
	text-align:center;
	margin:0px
}

.navbar a 
{
    float:left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding:16px 24px;
    text-decoration: none;
	margin-top:0%
	margin-left:0%;
	margin-right:0%;
	
}


.navbar a:hover
 {
    background: #ddd;
    color: black;
 }



input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}


</style>
</head>
<body>
<nav>
 <div class="navbar">
  <a href="buso.php">HOME</a>
  <a href="nxte.php">BOOKING</a>
   <a href="ticket cancel.php">CANCELLATION</a>
  <a href="contact us form.php">CONTACT </a>
   <a href="feedback form.php">FEEDBACK</a>
   <a href="login.php">LOGIN</a>
   <a href="admin.php">MASTER LOGIN</a>
</div>
</nav>
<br>
<h3 style="color:white;margin-top:10%">Contact Information</h3>

<div class="container">
 <!--  <form action="/action_page.php"> 
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="city">City</label>
    <select id="city" name="city">
	 <option value=""disabled selected>YOUR CITY</option>
     <option value="NEW DELHI">NEW DELHI</option>
     <option value="SONIPAT">SONIPAT</option>
     <option value="KARNAL">KARNAL</option>
	 <option value="AMBALA">AMBALA</option>
     <option value="LUDHIANA">LUDHIANA</option>
     <option value="JALANDHAR">JALANDHAR</option>
      <option value="AMRITSAR">AMRITSAR</option>
	  <option value="JAMMU">JAMMU</option>
    </select>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="Submit">-->
	<p>Call us at:9297953532<br>Email-us:Findbuses@gmail.com</p>
  </form>
</div>

</body>
</html>