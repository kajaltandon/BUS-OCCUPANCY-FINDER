<html>
<head>
<link href="Seat selection.css" rel="stylesheet">
</head>
<body>
	<div id="first">
		<h1>BOOK YOUR SEAT NOW!</h1>
		<div id="second">
		
		<p id="front"<b>FRONT</b></p>
			<table class="table">
  <tr>
  <td id="exit">EXIT</td>
  </tr>
  <tr>
    <td>1</td>
    <td id="b1" class="red">1<input type="checkbox" value="1" id="cb1" onclick="check1()"></td>
    <td id="b2" class="red">2<input type="checkbox" value="2" id="cb2" onclick="check2()"></td>
	<td></td>
    <td id="b3" class="green">3<input type="checkbox" value="3" id="cb3" onclick="check3()"></td>
	<td id="b4" class="green">4<input type="checkbox" value="4" id="cb4" onclick="check4()"></td>
  </tr>
  <tr>
    <td>2</td>
    <td id="b5" class="blue">5<input type="checkbox" value="5" id="cb5" onclick="check5()"></td>
    <td id="b6" class="blue">6<input type="checkbox" value="6" id="cb6" onclick="check6()"></td>
    <td></td>
    <td id="b7" class="blue">7<input type="checkbox" value="7" id="cb7" onclick="check7()"></td>
    <td id="b8" class="blue">8<input type="checkbox" value="8" id="cb8" onclick="check8()"></td>
  </tr>
  <tr>
    <td>3</td>
    <td id="b9" class="blue">9<input type="checkbox" value="9" id="cb9" onclick="check9()"></td>
    <td id="b10" class="blue">10<input type="checkbox" value="10" id="cb10" onclick="check10()"></td>
    <td></td>
    <td id="b11" class="blue">11<input type="checkbox" value="11" id="cb11" onclick="check11()"></td>
    <td id="b12" class="blue">12<input type="checkbox" value="12" id="cb12" onclick="check12()"></td>
  </tr>
  <tr>
     <td>4</td>
    <td id="b13" class="blue">13<input type="checkbox" value="13" id="cb13" onclick="check13()"></td>
    <td id="b14" class="blue">14<input type="checkbox" value="14" id="cb14" onclick="check14()"></td>
    <td></td>
    <td id="b15" class="blue">15<input type="checkbox" value="15" id="cb15" onclick="check15()"></td>
    <td id="b16" class="blue">16<input type="checkbox" value="16" id="cb16" onclick="check16()"></td>
  </tr>
  <tr>
    <td>5</td>
    <td id="b17" class="blue">17<input type="checkbox" value="17" id="cb17" onclick="check17()"></td>
    <td id="b18" class="blue">18<input type="checkbox" value="18" id="cb18" onclick="check18()"></td>
    <td></td>
    <td id="b19" class="blue">19<input type="checkbox" value="19" id="cb19" onclick="check19()"></td>
    <td id="b20" class="blue">20<input type="checkbox" value="20" id="cb20" onclick="check20()"></td>
  </tr>
   <tr>
    <td>6</td>
    <td id="b21" class="blue">21<input type="checkbox" value="21" id="cb21" onclick="check21()"></td>
    <td id="b22" class="blue">22<input type="checkbox" value="22" id="cb22" onclick="check22()"></td>
    <td></td>
    <td id="b23" class="blue">23<input type="checkbox" value="23" id="cb23" onclick="check23()"></td>
    <td id="b24" class="blue">24<input type="checkbox" value="24" id="cb24" onclick="check24()"></td>
  </tr>
 <tr>
    <td>7</td>
    <td id="b25" class="blue">25<input type="checkbox" value="25" id="cb25" onclick="check25()"></td>
    <td id="b26" class="blue">26<input type="checkbox" value="26" id="cb26" onclick="check26()"></td>
    <td></td>
    <td id="b27" class="blue">27<input type="checkbox" value="27" id="cb27" onclick="check27()"></td>
    <td id="b28" class="blue">28<input type="checkbox" value="28" id="cb28" onclick="check28()"></td>
  </tr>
  <tr>
    <td>8</td>
    <td id="b29" class="blue">29<input type="checkbox" value="29" id="cb29" onclick="check29()"></td>
    <td id="b30" class="blue">30<input type="checkbox" value="30" id="cb30" onclick="check30()"></td>
    <td></td>
    <td id="b31" class="blue">31<input type="checkbox" value="31" id="cb31" onclick="check31()" ></td>
    <td id="b32" class="blue">32<input type="checkbox" value="32" id="cb32" onclick="check32()"></td>
  </tr>
  <tr>
    <td>9</td>
    <td  id="b33" class="blue">33<input type="checkbox" value="33" id="cb33" onclick="check33()"></td>
    <td  id="b34" class="blue">34<input type="checkbox" value="34" id="cb34" onclick="check34()"></td>
    <td></td>
    <td  id="b35" class="blue">35<input type="checkbox" value="35" id="cb35" onclick="check35()"></td>
    <td  id="b36" class="blue">36<input type="checkbox" value="36" id="cb36" onclick="check36()" ></td>
  </tr>
  <tr>
    <td>10</td>
    <td id="b37" class="blue">37<input type="checkbox" value="37" id="cb37" onclick="check37()"></td>
    <td id="b38" class="blue">38<input type="checkbox" value="38" id="cb38" onclick="check38()"></td>
    <td id="b39" class="blue">39<input type="checkbox" value="39" id="cb39" onclick="check39()"></td>
   	<td id="b40" class="blue">40<input type="checkbox" value="40" id="cb40" onclick="check40()"></td>
	<td id="b41" class="blue">41<input type="checkbox" value="41" id="cb41" onclick="check41()"></td>
  </tr>
</table>

		</div>
		<div id="third"><table class="t2" style="border-spacing:8px;">
			<tr>
				<td style="background-color:green;width:20px; height:2px; border-radius:3px;"</td>
				<td class="red1"  style="width:200px;">Reserved for ladies</td>
			</tr>
			<tr>
				<td style="background-color:red;border-radius:3px;"></td>
				<td class="green1" style="width:200px;">Reserved for Pwd's</td>
			</tr>
			<tr>
				<td  style="background-color:blue;border-radius:3px;"></td>
				<td class="blue1" style="width:200px;">Vacant seats</td>
			</tr>
			<tr>
				<td  style="background-color:#FAD7A0;border-radius:3px;"></td>
				<td class="blue1" style="width:200px;">Selected seats</td>
			</tr>

		</table></div>
	</div>

<script>
function check1() {
    var checkBox = document.getElementById("cb1");
    var text = document.getElementById("b1");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "red";
    }
}
function check2() {
    var checkBox = document.getElementById("cb2");
    var text = document.getElementById("b2");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "red";
    }
}
function check3() {
    var checkBox = document.getElementById("cb3");
    var text = document.getElementById("b3");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "green";
    }
}
function check4() {
    var checkBox = document.getElementById("cb4");
    var text = document.getElementById("b4");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "green";
    }
}
function check5() {
    var checkBox = document.getElementById("cb5");
    var text = document.getElementById("b5");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check6() {
    var checkBox = document.getElementById("cb6");
    var text = document.getElementById("b6");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check7() {
    var checkBox = document.getElementById("cb7");
    var text = document.getElementById("b7");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check8() {
    var checkBox = document.getElementById("cb8");
    var text = document.getElementById("b8");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check9() {
    var checkBox = document.getElementById("cb9");
    var text = document.getElementById("b9");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check10() {
    var checkBox = document.getElementById("cb10");
    var text = document.getElementById("b10");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check11() {
    var checkBox = document.getElementById("cb11");
    var text = document.getElementById("b11");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check12() {
    var checkBox = document.getElementById("cb12");
    var text = document.getElementById("b12");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check13() {
    var checkBox = document.getElementById("cb13");
    var text = document.getElementById("b13");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check14() {
    var checkBox = document.getElementById("cb14");
    var text = document.getElementById("b14");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check15() {
    var checkBox = document.getElementById("cb15");
    var text = document.getElementById("b15");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check16() {
    var checkBox = document.getElementById("cb16");
    var text = document.getElementById("b16");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check17() {
    var checkBox = document.getElementById("cb17");
    var text = document.getElementById("b17");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check18() {
    var checkBox = document.getElementById("cb18");
    var text = document.getElementById("b18");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check19() {
    var checkBox = document.getElementById("cb19");
    var text = document.getElementById("b19");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check20() {
    var checkBox = document.getElementById("cb20");
    var text = document.getElementById("b20");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check21() {
    var checkBox = document.getElementById("cb21");
    var text = document.getElementById("b21");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check22() {
    var checkBox = document.getElementById("cb22");
    var text = document.getElementById("b22");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check23() {
    var checkBox = document.getElementById("cb23");
    var text = document.getElementById("b23");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check24() {
    var checkBox = document.getElementById("cb24");
    var text = document.getElementById("b24");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check25() {
    var checkBox = document.getElementById("cb25");
    var text = document.getElementById("b25");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check26() {
    var checkBox = document.getElementById("cb26");
    var text = document.getElementById("b26");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check27() {
    var checkBox = document.getElementById("cb27");
    var text = document.getElementById("b27");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check28() {
    var checkBox = document.getElementById("cb28");
    var text = document.getElementById("b28");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check29() {
    var checkBox = document.getElementById("cb29");
    var text = document.getElementById("b29");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check30() {
    var checkBox = document.getElementById("cb30");
    var text = document.getElementById("b30");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}function check31() {
    var checkBox = document.getElementById("cb31");
    var text = document.getElementById("b31");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check32() {
    var checkBox = document.getElementById("cb32");
    var text = document.getElementById("b32");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check33() {
    var checkBox = document.getElementById("cb33");
    var text = document.getElementById("b33");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check34() {
    var checkBox = document.getElementById("cb34");
    var text = document.getElementById("b34");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check35() {
    var checkBox = document.getElementById("cb35");
    var text = document.getElementById("b35");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check36() {
    var checkBox = document.getElementById("cb36");
    var text = document.getElementById("b36");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check37() {
    var checkBox = document.getElementById("cb37");
    var text = document.getElementById("b37");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check38() {
    var checkBox = document.getElementById("cb38");
    var text = document.getElementById("b38");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check39() {
    var checkBox = document.getElementById("cb39");
    var text = document.getElementById("b39");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check40() {
    var checkBox = document.getElementById("cb40");
    var text = document.getElementById("b40");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
}
function check41() {
    var checkBox = document.getElementById("cb41");
    var text = document.getElementById("b41");
    if (checkBox.checked == true){
      
        text.style.backgroundColor ="#FAD7A0";
    } else {
       text.style.backgroundColor = "blue";
    }
 }
</script>
</body>
</html>