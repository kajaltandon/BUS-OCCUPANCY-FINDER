<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

.container {
    position: relative;
    text-align: center;
    color: white;
}
.centered {
    position: absolute;
	color:white;
	font-size:40px;
    top: 35%;
    left: 50%;
    transform: translate(-40%, -40%);
}
img:hover {
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
.image{
width:110%;
 height:80%;
}	
}
</style>
</head>
<body>
<center>
<div class="container">
  <img src="banner.jpg" ;>
  <div class="centered"><b>Thanku for your submission ! We will contact you soon.<b></div>
</div>
</body>
</html> 
