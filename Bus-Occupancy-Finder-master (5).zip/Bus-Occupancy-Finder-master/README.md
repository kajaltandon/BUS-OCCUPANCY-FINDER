# Bus-Occupancy-Finder

This project is made as part of Smart India Hackathon 2018, a problem statement of government of punjab. The database used is dummy and server is localhost Wamp. This webapp is mainly considered on providing occupancy and bus from a station to station. My work in this project is leading the team,frontend handling and  backend handling.

## About the project
Bus occupancy finder is a web based app that helps the user to find out the vacancy of no of seats in the bus coming towards the bus stop
and provides the user ability to finding out of the seat vacancy in the respective bus and booking of the seat,it also includes online ticket generation and pre-book of seats.

### To know more read "Bus Occupancy(1).pdf"

## How to use?
Read "STEPS TO INSTALL.pdf".
